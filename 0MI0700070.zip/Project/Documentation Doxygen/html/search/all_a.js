var searchData=
[
  ['matrix_0',['Matrix',['../class_matrix.html',1,'Matrix&lt; T &gt;'],['../class_matrix.html#a9d567e3a121b1be0c3f9c461cab524fe',1,'Matrix::Matrix()'],['../class_matrix.html#adc8344cb0b2405995b07c03b60883c56',1,'Matrix::Matrix(int _rows, int _cols)'],['../class_matrix.html#ab829dc851f8fcafee35a729a31457d73',1,'Matrix::Matrix(const Matrix &amp;other)']]],
  ['matrix_3c_20pixel_20_2a_20_3e_1',['Matrix&lt; Pixel * &gt;',['../class_matrix.html',1,'']]],
  ['monochrome_2',['monochrome',['../class_transform.html#ad5d38ae725d8825e8c154d8238b16311',1,'Transform']]]
];
