var searchData=
[
  ['add_0',['add',['../class_workspace.html#af7ce6173c920a16a488a7d36c1af8275',1,'Workspace']]],
  ['addpicture_1',['addPicture',['../class_session.html#ac9ef86ca32342723a3d219a55f0f8da5',1,'Session']]],
  ['addtransformation_2',['addTransformation',['../class_picture.html#a5684927049ef68864c2b0f34806b515a',1,'Picture::addTransformation()'],['../class_session.html#a5c6154b5d80c68aa8242ebf91db0464c',1,'Session::addTransformation()'],['../class_workspace.html#a3e8e6f0de36ea0ab2ae24f5d1e7c7c25',1,'Workspace::addTransformation()']]]
];
