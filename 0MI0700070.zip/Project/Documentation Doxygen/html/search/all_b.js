var searchData=
[
  ['negative_0',['negative',['../class_transform.html#a0a14681e36b137e36db71eb88fc3e32f',1,'Transform']]]
];
