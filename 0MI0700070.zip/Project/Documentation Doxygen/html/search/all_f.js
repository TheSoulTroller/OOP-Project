var searchData=
[
  ['save_0',['save',['../class_session.html#aec0dc9e097213458c68d32d7f09d8cfc',1,'Session']]],
  ['savesession_1',['saveSession',['../class_workspace.html#a517914de819c4d734c5ecf944c4669c4',1,'Workspace']]],
  ['session_2',['Session',['../class_session.html',1,'Session'],['../class_session.html#aa4b4d16918e40cce563d629bea3f0c8d',1,'Session::Session()=default'],['../class_session.html#aeb0d7b415bebd81c362bdc30fa840212',1,'Session::Session(int _id)']]],
  ['sessioninfo_3',['sessionInfo',['../class_session.html#ac031ecc84b53a7dbda9d2960d22ba6c0',1,'Session']]],
  ['set_4',['set',['../class_matrix.html#a2b9339d47afde3394c85e826fc0e3748',1,'Matrix']]],
  ['setblack_5',['setBlack',['../class_b_w_pixel.html#a328d0992b8b5259b5e855fa3b9f4fd68',1,'BWPixel']]],
  ['setblue_6',['setBlue',['../class_r_g_b_pixel.html#aa1ca73dd090a71386e71aaddd49a4a44',1,'RGBPixel']]],
  ['setgray_7',['setGray',['../class_g_pixel.html#abe70ac73ab20cd1470d3536f632061ae',1,'GPixel']]],
  ['setgreen_8',['setGreen',['../class_r_g_b_pixel.html#a491a215e284bd27ba2ac1157934f5db8',1,'RGBPixel']]],
  ['setpbm_5fpicture_9',['setPBM_Picture',['../class_picture.html#a22040797143d5c875716b676d1138b2b',1,'Picture']]],
  ['setpgm_5fpicture_10',['setPGM_Picture',['../class_picture.html#ac03bce360b92e5a9d52c47bfa3eebafd',1,'Picture']]],
  ['setppm_5fpicture_11',['setPPM_Picture',['../class_picture.html#ae5c3c1ee8573388eaa644530e7c5ec2b',1,'Picture']]],
  ['setred_12',['setRed',['../class_r_g_b_pixel.html#a6317c23b09e6f39d4aaa852c9fb0e36a',1,'RGBPixel']]],
  ['split_13',['split',['../class_string.html#a8a067c1ce865e826489f4b17e1fb666d',1,'String']]],
  ['stopcreating_14',['stopCreating',['../class_picture.html#a6c06b2cac0baba9f82da6572f81ba84a',1,'Picture']]],
  ['string_15',['String',['../class_string.html',1,'String'],['../class_string.html#a8a7ef356e05eb9b1ea1ab518baee3095',1,'String::String()'],['../class_string.html#af5440eb5f334d91d4f8da9f8e288aed8',1,'String::String(const char *source, int length)'],['../class_string.html#a8767cdc62cc067a48496fcb095d6d186',1,'String::String(const char *source)'],['../class_string.html#afc158dffcdf56e601bd640cbacdfcd3c',1,'String::String(const String &amp;other)']]],
  ['switchsession_16',['switchSession',['../class_workspace.html#ad287c76e02dfa270aca9ec5f636d5f77',1,'Workspace']]]
];
