var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_string.html#ae7d3addff502747e76adb2e6c7f1c815',1,'String']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_string.html#a8e6f6efe4735bdfcffce6623efd861c5',1,'String']]]
];
