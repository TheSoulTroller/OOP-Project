var searchData=
[
  ['fliphorizontal_0',['flipHorizontal',['../class_matrix.html#a1f7a7fda06ea64f7330de652dd32d3e2',1,'Matrix']]],
  ['flipvertical_1',['flipVertical',['../class_matrix.html#afc884bfd91aa440437caf5fa46b3cf9c',1,'Matrix']]]
];
