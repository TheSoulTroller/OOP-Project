var searchData=
[
  ['datetime_0',['DateTime',['../struct_date_time.html',1,'']]]
];
