var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuvw~п",
  1: "bdgimprstvw",
  2: "abcdefghilmnoprstuvw~",
  3: "o",
  4: "п"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "related",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Указател към не филтриран списък на всички членове",
  1: "Класове",
  2: "Функции",
  3: "Приятели",
  4: "Страници"
};

