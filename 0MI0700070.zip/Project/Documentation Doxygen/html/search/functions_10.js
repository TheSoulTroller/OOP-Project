var searchData=
[
  ['transform_0',['transform',['../class_transform.html#a9aa703bfbd188611dc4b107524501b1d',1,'Transform']]],
  ['trim_1',['trim',['../class_picture.html#a1f6e39a1bfbad3d1e5a44335fc48be90',1,'Picture']]]
];
