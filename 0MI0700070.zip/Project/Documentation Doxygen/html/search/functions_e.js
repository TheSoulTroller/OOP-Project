var searchData=
[
  ['removeduplicates_0',['removeDuplicates',['../class_vector.html#a116cf85080058edc095b4e0f0f550e3a',1,'Vector']]],
  ['removeinvalid_1',['removeInvalid',['../class_interpreter.html#a6900c0fdedc73e37672b9d5c60f3c031',1,'Interpreter']]],
  ['removetransformation_2',['removeTransformation',['../class_picture.html#a4976a5703d917ba6baf921bdfad8befa',1,'Picture::removeTransformation()'],['../class_session.html#a01cb513dac8d4d3fe619a2cbb96f51e4',1,'Session::removeTransformation()'],['../class_workspace.html#ad3a20d5003f5f4572ce620b66814c79d',1,'Workspace::removeTransformation()']]],
  ['resize_3',['resize',['../class_string.html#ae3da7bca5f1d45736b0b57fa61a45ed7',1,'String']]],
  ['rgbpixel_4',['RGBPixel',['../class_r_g_b_pixel.html#a88a66743b678c2095d765fd4f9361f37',1,'RGBPixel']]],
  ['right_5',['right',['../class_transform.html#a446519d9b923abbd41e13fd4ade6f75a',1,'Transform']]],
  ['rotateleft_6',['rotateLeft',['../class_matrix.html#a0f06bde0034fae00b955e717d0cc0f47',1,'Matrix']]],
  ['rotateright_7',['rotateRight',['../class_matrix.html#a62fee841dffd817d4ff50d69688b6544',1,'Matrix']]]
];
