var searchData=
[
  ['erase_0',['erase',['../class_matrix.html#aea444fde13ce3394a82cbb4f68d71c1b',1,'Matrix::erase()'],['../class_string.html#a3ce2ea55be9ec912bb2dbc88d461b479',1,'String::erase()'],['../class_vector.html#a0b9d29e8fd355e6e9a5519beb85df657',1,'Vector::erase()']]]
];
