var searchData=
[
  ['upsize_0',['upsize',['../class_vector.html#a7b55fd0b53e59b74661bdc1575ec0dfb',1,'Vector']]]
];
