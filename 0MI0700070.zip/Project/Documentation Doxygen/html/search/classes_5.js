var searchData=
[
  ['picture_0',['Picture',['../class_picture.html',1,'']]],
  ['pixel_1',['Pixel',['../class_pixel.html',1,'']]]
];
