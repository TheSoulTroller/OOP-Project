var searchData=
[
  ['datetime_0',['DateTime',['../struct_date_time.html',1,'']]],
  ['dotransformations_1',['doTransformations',['../class_picture.html#aeb88e1826fc738b7d4caa541a05287a2',1,'Picture']]],
  ['downsize_2',['downsize',['../class_string.html#af64cb7af442615b65ef832bea3e548e9',1,'String::downsize()'],['../class_vector.html#a3f8a9754f0d982f4fabcf348f5b96805',1,'Vector::downsize()']]]
];
