var searchData=
[
  ['matrix_0',['Matrix',['../class_matrix.html',1,'']]],
  ['matrix_3c_20pixel_20_2a_20_3e_1',['Matrix&lt; Pixel * &gt;',['../class_matrix.html',1,'']]]
];
