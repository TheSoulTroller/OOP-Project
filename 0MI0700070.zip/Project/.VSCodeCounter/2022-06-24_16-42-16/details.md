# Details

Date : 2022-06-24 16:42:16

Directory d:\\OOP\\Project

Total : 225 files,  21560 codes, 1188 comments, 1330 blanks, all 24078 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Documentation Doxygen/html/_black_white_8h_source.html](/Documentation%20Doxygen/html/_black_white_8h_source.html) | HTML | 118 | 5 | 3 | 126 |
| [Documentation Doxygen/html/_gray_8h_source.html](/Documentation%20Doxygen/html/_gray_8h_source.html) | HTML | 117 | 5 | 3 | 125 |
| [Documentation Doxygen/html/_interpreter_8h_source.html](/Documentation%20Doxygen/html/_interpreter_8h_source.html) | HTML | 334 | 5 | 3 | 342 |
| [Documentation Doxygen/html/_matrix_8h_source.html](/Documentation%20Doxygen/html/_matrix_8h_source.html) | HTML | 286 | 5 | 3 | 294 |
| [Documentation Doxygen/html/_netpbm_8h_source.html](/Documentation%20Doxygen/html/_netpbm_8h_source.html) | HTML | 485 | 5 | 3 | 493 |
| [Documentation Doxygen/html/_p_b_m_8h_source.html](/Documentation%20Doxygen/html/_p_b_m_8h_source.html) | HTML | 104 | 5 | 3 | 112 |
| [Documentation Doxygen/html/_p_g_m_8h_source.html](/Documentation%20Doxygen/html/_p_g_m_8h_source.html) | HTML | 68 | 5 | 3 | 76 |
| [Documentation Doxygen/html/_p_p_m_8h_source.html](/Documentation%20Doxygen/html/_p_p_m_8h_source.html) | HTML | 68 | 5 | 3 | 76 |
| [Documentation Doxygen/html/_pixel_8h_source.html](/Documentation%20Doxygen/html/_pixel_8h_source.html) | HTML | 85 | 5 | 3 | 93 |
| [Documentation Doxygen/html/_r_g_b_8h_source.html](/Documentation%20Doxygen/html/_r_g_b_8h_source.html) | HTML | 157 | 5 | 3 | 165 |
| [Documentation Doxygen/html/_session_8h_source.html](/Documentation%20Doxygen/html/_session_8h_source.html) | HTML | 191 | 5 | 3 | 199 |
| [Documentation Doxygen/html/_stack_8h_source.html](/Documentation%20Doxygen/html/_stack_8h_source.html) | HTML | 90 | 5 | 3 | 98 |
| [Documentation Doxygen/html/_string_8h_source.html](/Documentation%20Doxygen/html/_string_8h_source.html) | HTML | 366 | 5 | 3 | 374 |
| [Documentation Doxygen/html/_time_8h_source.html](/Documentation%20Doxygen/html/_time_8h_source.html) | HTML | 91 | 5 | 3 | 99 |
| [Documentation Doxygen/html/_transformation_8h_source.html](/Documentation%20Doxygen/html/_transformation_8h_source.html) | HTML | 469 | 5 | 3 | 477 |
| [Documentation Doxygen/html/_vector_8h_source.html](/Documentation%20Doxygen/html/_vector_8h_source.html) | HTML | 278 | 5 | 3 | 286 |
| [Documentation Doxygen/html/_workspace_8h_source.html](/Documentation%20Doxygen/html/_workspace_8h_source.html) | HTML | 167 | 5 | 3 | 175 |
| [Documentation Doxygen/html/annotated.html](/Documentation%20Doxygen/html/annotated.html) | HTML | 85 | 5 | 3 | 93 |
| [Documentation Doxygen/html/class_b_w_pixel-members.html](/Documentation%20Doxygen/html/class_b_w_pixel-members.html) | HTML | 77 | 5 | 4 | 86 |
| [Documentation Doxygen/html/class_b_w_pixel.html](/Documentation%20Doxygen/html/class_b_w_pixel.html) | HTML | 181 | 5 | 13 | 199 |
| [Documentation Doxygen/html/class_g_pixel-members.html](/Documentation%20Doxygen/html/class_g_pixel-members.html) | HTML | 77 | 5 | 4 | 86 |
| [Documentation Doxygen/html/class_g_pixel.html](/Documentation%20Doxygen/html/class_g_pixel.html) | HTML | 175 | 5 | 11 | 191 |
| [Documentation Doxygen/html/class_interpreter-members.html](/Documentation%20Doxygen/html/class_interpreter-members.html) | HTML | 72 | 5 | 4 | 81 |
| [Documentation Doxygen/html/class_interpreter.html](/Documentation%20Doxygen/html/class_interpreter.html) | HTML | 88 | 5 | 3 | 96 |
| [Documentation Doxygen/html/class_matrix-members.html](/Documentation%20Doxygen/html/class_matrix-members.html) | HTML | 88 | 5 | 4 | 97 |
| [Documentation Doxygen/html/class_matrix.html](/Documentation%20Doxygen/html/class_matrix.html) | HTML | 162 | 5 | 5 | 172 |
| [Documentation Doxygen/html/class_p_b_m-members.html](/Documentation%20Doxygen/html/class_p_b_m-members.html) | HTML | 76 | 5 | 4 | 85 |
| [Documentation Doxygen/html/class_p_b_m.html](/Documentation%20Doxygen/html/class_p_b_m.html) | HTML | 142 | 5 | 8 | 155 |
| [Documentation Doxygen/html/class_picture-members.html](/Documentation%20Doxygen/html/class_picture-members.html) | HTML | 95 | 5 | 4 | 104 |
| [Documentation Doxygen/html/class_picture.html](/Documentation%20Doxygen/html/class_picture.html) | HTML | 158 | 5 | 3 | 166 |
| [Documentation Doxygen/html/class_pixel-members.html](/Documentation%20Doxygen/html/class_pixel-members.html) | HTML | 73 | 5 | 4 | 82 |
| [Documentation Doxygen/html/class_pixel.html](/Documentation%20Doxygen/html/class_pixel.html) | HTML | 157 | 5 | 13 | 175 |
| [Documentation Doxygen/html/class_r_g_b_pixel-members.html](/Documentation%20Doxygen/html/class_r_g_b_pixel-members.html) | HTML | 81 | 5 | 4 | 90 |
| [Documentation Doxygen/html/class_r_g_b_pixel.html](/Documentation%20Doxygen/html/class_r_g_b_pixel.html) | HTML | 195 | 5 | 13 | 213 |
| [Documentation Doxygen/html/class_session-members.html](/Documentation%20Doxygen/html/class_session-members.html) | HTML | 83 | 5 | 4 | 92 |
| [Documentation Doxygen/html/class_session.html](/Documentation%20Doxygen/html/class_session.html) | HTML | 243 | 5 | 17 | 265 |
| [Documentation Doxygen/html/class_stack-members.html](/Documentation%20Doxygen/html/class_stack-members.html) | HTML | 77 | 5 | 4 | 86 |
| [Documentation Doxygen/html/class_stack.html](/Documentation%20Doxygen/html/class_stack.html) | HTML | 94 | 5 | 3 | 102 |
| [Documentation Doxygen/html/class_string-members.html](/Documentation%20Doxygen/html/class_string-members.html) | HTML | 98 | 5 | 4 | 107 |
| [Documentation Doxygen/html/class_string.html](/Documentation%20Doxygen/html/class_string.html) | HTML | 205 | 5 | 5 | 215 |
| [Documentation Doxygen/html/class_transform-members.html](/Documentation%20Doxygen/html/class_transform-members.html) | HTML | 79 | 5 | 4 | 88 |
| [Documentation Doxygen/html/class_transform.html](/Documentation%20Doxygen/html/class_transform.html) | HTML | 109 | 5 | 3 | 117 |
| [Documentation Doxygen/html/class_vector-members.html](/Documentation%20Doxygen/html/class_vector-members.html) | HTML | 92 | 5 | 4 | 101 |
| [Documentation Doxygen/html/class_vector.html](/Documentation%20Doxygen/html/class_vector.html) | HTML | 178 | 5 | 5 | 188 |
| [Documentation Doxygen/html/class_workspace-members.html](/Documentation%20Doxygen/html/class_workspace-members.html) | HTML | 83 | 5 | 4 | 92 |
| [Documentation Doxygen/html/class_workspace.html](/Documentation%20Doxygen/html/class_workspace.html) | HTML | 137 | 5 | 5 | 147 |
| [Documentation Doxygen/html/classes.html](/Documentation%20Doxygen/html/classes.html) | HTML | 104 | 5 | 3 | 112 |
| [Documentation Doxygen/html/dir_31d546a7220d2d0f2290ebc917bc5425.html](/Documentation%20Doxygen/html/dir_31d546a7220d2d0f2290ebc917bc5425.html) | HTML | 84 | 5 | 3 | 92 |
| [Documentation Doxygen/html/dir_b4ee9d9f79210c426cfe94ddbc714822.html](/Documentation%20Doxygen/html/dir_b4ee9d9f79210c426cfe94ddbc714822.html) | HTML | 80 | 5 | 3 | 88 |
| [Documentation Doxygen/html/dir_ed734d3ca306bf0333720362dd4a518b.html](/Documentation%20Doxygen/html/dir_ed734d3ca306bf0333720362dd4a518b.html) | HTML | 86 | 5 | 3 | 94 |
| [Documentation Doxygen/html/doxygen.css](/Documentation%20Doxygen/html/doxygen.css) | CSS | 1,497 | 48 | 297 | 1,842 |
| [Documentation Doxygen/html/doxygen.svg](/Documentation%20Doxygen/html/doxygen.svg) | XML | 26 | 0 | 1 | 27 |
| [Documentation Doxygen/html/dynsections.js](/Documentation%20Doxygen/html/dynsections.js) | JavaScript | 80 | 32 | 10 | 122 |
| [Documentation Doxygen/html/files.html](/Documentation%20Doxygen/html/files.html) | HTML | 87 | 5 | 3 | 95 |
| [Documentation Doxygen/html/functions.html](/Documentation%20Doxygen/html/functions.html) | HTML | 174 | 5 | 38 | 217 |
| [Documentation Doxygen/html/functions_func.html](/Documentation%20Doxygen/html/functions_func.html) | HTML | 172 | 5 | 38 | 215 |
| [Documentation Doxygen/html/functions_rela.html](/Documentation%20Doxygen/html/functions_rela.html) | HTML | 69 | 5 | 3 | 77 |
| [Documentation Doxygen/html/hierarchy.html](/Documentation%20Doxygen/html/hierarchy.html) | HTML | 89 | 5 | 3 | 97 |
| [Documentation Doxygen/html/index.html](/Documentation%20Doxygen/html/index.html) | HTML | 68 | 5 | 3 | 76 |
| [Documentation Doxygen/html/jquery.js](/Documentation%20Doxygen/html/jquery.js) | JavaScript | 7 | 27 | 1 | 35 |
| [Documentation Doxygen/html/menu.js](/Documentation%20Doxygen/html/menu.js) | JavaScript | 107 | 27 | 2 | 136 |
| [Documentation Doxygen/html/menudata.js](/Documentation%20Doxygen/html/menudata.js) | JavaScript | 48 | 24 | 1 | 73 |
| [Documentation Doxygen/html/search/all_0.html](/Documentation%20Doxygen/html/search/all_0.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_0.js](/Documentation%20Doxygen/html/search/all_0.js) | JavaScript | 6 | 0 | 1 | 7 |
| [Documentation Doxygen/html/search/all_1.html](/Documentation%20Doxygen/html/search/all_1.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_1.js](/Documentation%20Doxygen/html/search/all_1.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/all_10.html](/Documentation%20Doxygen/html/search/all_10.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_10.js](/Documentation%20Doxygen/html/search/all_10.js) | JavaScript | 8 | 0 | 1 | 9 |
| [Documentation Doxygen/html/search/all_11.html](/Documentation%20Doxygen/html/search/all_11.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_11.js](/Documentation%20Doxygen/html/search/all_11.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/all_12.html](/Documentation%20Doxygen/html/search/all_12.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_12.js](/Documentation%20Doxygen/html/search/all_12.js) | JavaScript | 9 | 0 | 1 | 10 |
| [Documentation Doxygen/html/search/all_2.html](/Documentation%20Doxygen/html/search/all_2.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_2.js](/Documentation%20Doxygen/html/search/all_2.js) | JavaScript | 6 | 0 | 1 | 7 |
| [Documentation Doxygen/html/search/all_3.html](/Documentation%20Doxygen/html/search/all_3.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_3.js](/Documentation%20Doxygen/html/search/all_3.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/all_4.html](/Documentation%20Doxygen/html/search/all_4.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_4.js](/Documentation%20Doxygen/html/search/all_4.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/all_5.html](/Documentation%20Doxygen/html/search/all_5.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_5.js](/Documentation%20Doxygen/html/search/all_5.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/all_6.html](/Documentation%20Doxygen/html/search/all_6.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_6.js](/Documentation%20Doxygen/html/search/all_6.js) | JavaScript | 18 | 0 | 1 | 19 |
| [Documentation Doxygen/html/search/all_7.html](/Documentation%20Doxygen/html/search/all_7.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_7.js](/Documentation%20Doxygen/html/search/all_7.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/all_8.html](/Documentation%20Doxygen/html/search/all_8.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_8.js](/Documentation%20Doxygen/html/search/all_8.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/all_9.html](/Documentation%20Doxygen/html/search/all_9.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_9.js](/Documentation%20Doxygen/html/search/all_9.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/all_a.html](/Documentation%20Doxygen/html/search/all_a.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_a.js](/Documentation%20Doxygen/html/search/all_a.js) | JavaScript | 12 | 0 | 1 | 13 |
| [Documentation Doxygen/html/search/all_b.html](/Documentation%20Doxygen/html/search/all_b.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_b.js](/Documentation%20Doxygen/html/search/all_b.js) | JavaScript | 8 | 0 | 1 | 9 |
| [Documentation Doxygen/html/search/all_c.html](/Documentation%20Doxygen/html/search/all_c.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_c.js](/Documentation%20Doxygen/html/search/all_c.js) | JavaScript | 9 | 0 | 1 | 10 |
| [Documentation Doxygen/html/search/all_d.html](/Documentation%20Doxygen/html/search/all_d.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_d.js](/Documentation%20Doxygen/html/search/all_d.js) | JavaScript | 16 | 0 | 1 | 17 |
| [Documentation Doxygen/html/search/all_e.html](/Documentation%20Doxygen/html/search/all_e.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_e.js](/Documentation%20Doxygen/html/search/all_e.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/all_f.html](/Documentation%20Doxygen/html/search/all_f.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/all_f.js](/Documentation%20Doxygen/html/search/all_f.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/classes_0.html](/Documentation%20Doxygen/html/search/classes_0.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_0.js](/Documentation%20Doxygen/html/search/classes_0.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/classes_1.html](/Documentation%20Doxygen/html/search/classes_1.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_1.js](/Documentation%20Doxygen/html/search/classes_1.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/classes_2.html](/Documentation%20Doxygen/html/search/classes_2.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_2.js](/Documentation%20Doxygen/html/search/classes_2.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/classes_3.html](/Documentation%20Doxygen/html/search/classes_3.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_3.js](/Documentation%20Doxygen/html/search/classes_3.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/classes_4.html](/Documentation%20Doxygen/html/search/classes_4.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_4.js](/Documentation%20Doxygen/html/search/classes_4.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/classes_5.html](/Documentation%20Doxygen/html/search/classes_5.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_5.js](/Documentation%20Doxygen/html/search/classes_5.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/classes_6.html](/Documentation%20Doxygen/html/search/classes_6.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_6.js](/Documentation%20Doxygen/html/search/classes_6.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/classes_7.html](/Documentation%20Doxygen/html/search/classes_7.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_7.js](/Documentation%20Doxygen/html/search/classes_7.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/classes_8.html](/Documentation%20Doxygen/html/search/classes_8.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_8.js](/Documentation%20Doxygen/html/search/classes_8.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/classes_9.html](/Documentation%20Doxygen/html/search/classes_9.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_9.js](/Documentation%20Doxygen/html/search/classes_9.js) | JavaScript | 7 | 0 | 1 | 8 |
| [Documentation Doxygen/html/search/classes_a.html](/Documentation%20Doxygen/html/search/classes_a.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/classes_a.js](/Documentation%20Doxygen/html/search/classes_a.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/close.svg](/Documentation%20Doxygen/html/search/close.svg) | XML | 31 | 0 | 1 | 32 |
| [Documentation Doxygen/html/search/functions_0.html](/Documentation%20Doxygen/html/search/functions_0.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_0.js](/Documentation%20Doxygen/html/search/functions_0.js) | JavaScript | 6 | 0 | 1 | 7 |
| [Documentation Doxygen/html/search/functions_1.html](/Documentation%20Doxygen/html/search/functions_1.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_1.js](/Documentation%20Doxygen/html/search/functions_1.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/functions_10.html](/Documentation%20Doxygen/html/search/functions_10.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_10.js](/Documentation%20Doxygen/html/search/functions_10.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/functions_11.html](/Documentation%20Doxygen/html/search/functions_11.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_11.js](/Documentation%20Doxygen/html/search/functions_11.js) | JavaScript | 9 | 0 | 1 | 10 |
| [Documentation Doxygen/html/search/functions_2.html](/Documentation%20Doxygen/html/search/functions_2.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_2.js](/Documentation%20Doxygen/html/search/functions_2.js) | JavaScript | 6 | 0 | 1 | 7 |
| [Documentation Doxygen/html/search/functions_3.html](/Documentation%20Doxygen/html/search/functions_3.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_3.js](/Documentation%20Doxygen/html/search/functions_3.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/functions_4.html](/Documentation%20Doxygen/html/search/functions_4.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_4.js](/Documentation%20Doxygen/html/search/functions_4.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/functions_5.html](/Documentation%20Doxygen/html/search/functions_5.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_5.js](/Documentation%20Doxygen/html/search/functions_5.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/functions_6.html](/Documentation%20Doxygen/html/search/functions_6.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_6.js](/Documentation%20Doxygen/html/search/functions_6.js) | JavaScript | 18 | 0 | 1 | 19 |
| [Documentation Doxygen/html/search/functions_7.html](/Documentation%20Doxygen/html/search/functions_7.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_7.js](/Documentation%20Doxygen/html/search/functions_7.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/functions_8.html](/Documentation%20Doxygen/html/search/functions_8.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_8.js](/Documentation%20Doxygen/html/search/functions_8.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/functions_9.html](/Documentation%20Doxygen/html/search/functions_9.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_9.js](/Documentation%20Doxygen/html/search/functions_9.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/functions_a.html](/Documentation%20Doxygen/html/search/functions_a.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_a.js](/Documentation%20Doxygen/html/search/functions_a.js) | JavaScript | 10 | 0 | 1 | 11 |
| [Documentation Doxygen/html/search/functions_b.html](/Documentation%20Doxygen/html/search/functions_b.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_b.js](/Documentation%20Doxygen/html/search/functions_b.js) | JavaScript | 6 | 0 | 1 | 7 |
| [Documentation Doxygen/html/search/functions_c.html](/Documentation%20Doxygen/html/search/functions_c.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_c.js](/Documentation%20Doxygen/html/search/functions_c.js) | JavaScript | 9 | 0 | 1 | 10 |
| [Documentation Doxygen/html/search/functions_d.html](/Documentation%20Doxygen/html/search/functions_d.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_d.js](/Documentation%20Doxygen/html/search/functions_d.js) | JavaScript | 16 | 0 | 1 | 17 |
| [Documentation Doxygen/html/search/functions_e.html](/Documentation%20Doxygen/html/search/functions_e.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_e.js](/Documentation%20Doxygen/html/search/functions_e.js) | JavaScript | 4 | 0 | 1 | 5 |
| [Documentation Doxygen/html/search/functions_f.html](/Documentation%20Doxygen/html/search/functions_f.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/functions_f.js](/Documentation%20Doxygen/html/search/functions_f.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/mag_sel.svg](/Documentation%20Doxygen/html/search/mag_sel.svg) | XML | 72 | 1 | 2 | 75 |
| [Documentation Doxygen/html/search/nomatches.html](/Documentation%20Doxygen/html/search/nomatches.html) | HTML | 13 | 0 | 1 | 14 |
| [Documentation Doxygen/html/search/related_0.html](/Documentation%20Doxygen/html/search/related_0.html) | HTML | 37 | 0 | 1 | 38 |
| [Documentation Doxygen/html/search/related_0.js](/Documentation%20Doxygen/html/search/related_0.js) | JavaScript | 5 | 0 | 1 | 6 |
| [Documentation Doxygen/html/search/search.css](/Documentation%20Doxygen/html/search/search.css) | CSS | 211 | 8 | 45 | 264 |
| [Documentation Doxygen/html/search/search.js](/Documentation%20Doxygen/html/search/search.js) | JavaScript | 677 | 60 | 66 | 803 |
| [Documentation Doxygen/html/search/searchdata.js](/Documentation%20Doxygen/html/search/searchdata.js) | JavaScript | 21 | 0 | 4 | 25 |
| [Documentation Doxygen/html/struct_date_time-members.html](/Documentation%20Doxygen/html/struct_date_time-members.html) | HTML | 71 | 5 | 4 | 80 |
| [Documentation Doxygen/html/struct_date_time.html](/Documentation%20Doxygen/html/struct_date_time.html) | HTML | 113 | 5 | 8 | 126 |
| [Documentation Doxygen/html/tabs.css](/Documentation%20Doxygen/html/tabs.css) | CSS | 1 | 0 | 0 | 1 |
| [Documentation Doxygen/latex/Makefile](/Documentation%20Doxygen/latex/Makefile) | Makefile | 22 | 0 | 6 | 28 |
| [Documentation Doxygen/latex/_black_white_8h_source.tex](/Documentation%20Doxygen/latex/_black_white_8h_source.tex) | LaTeX | 43 | 0 | 3 | 46 |
| [Documentation Doxygen/latex/_gray_8h_source.tex](/Documentation%20Doxygen/latex/_gray_8h_source.tex) | LaTeX | 42 | 0 | 3 | 45 |
| [Documentation Doxygen/latex/_interpreter_8h_source.tex](/Documentation%20Doxygen/latex/_interpreter_8h_source.tex) | LaTeX | 250 | 0 | 3 | 253 |
| [Documentation Doxygen/latex/_matrix_8h_source.tex](/Documentation%20Doxygen/latex/_matrix_8h_source.tex) | LaTeX | 202 | 0 | 3 | 205 |
| [Documentation Doxygen/latex/_netpbm_8h_source.tex](/Documentation%20Doxygen/latex/_netpbm_8h_source.tex) | LaTeX | 398 | 0 | 3 | 401 |
| [Documentation Doxygen/latex/_p_b_m_8h_source.tex](/Documentation%20Doxygen/latex/_p_b_m_8h_source.tex) | LaTeX | 37 | 0 | 3 | 40 |
| [Documentation Doxygen/latex/_p_g_m_8h_source.tex](/Documentation%20Doxygen/latex/_p_g_m_8h_source.tex) | LaTeX | 3 | 0 | 3 | 6 |
| [Documentation Doxygen/latex/_p_p_m_8h_source.tex](/Documentation%20Doxygen/latex/_p_p_m_8h_source.tex) | LaTeX | 3 | 0 | 3 | 6 |
| [Documentation Doxygen/latex/_pixel_8h_source.tex](/Documentation%20Doxygen/latex/_pixel_8h_source.tex) | LaTeX | 13 | 0 | 3 | 16 |
| [Documentation Doxygen/latex/_r_g_b_8h_source.tex](/Documentation%20Doxygen/latex/_r_g_b_8h_source.tex) | LaTeX | 78 | 0 | 3 | 81 |
| [Documentation Doxygen/latex/_session_8h_source.tex](/Documentation%20Doxygen/latex/_session_8h_source.tex) | LaTeX | 109 | 0 | 3 | 112 |
| [Documentation Doxygen/latex/_stack_8h_source.tex](/Documentation%20Doxygen/latex/_stack_8h_source.tex) | LaTeX | 21 | 0 | 3 | 24 |
| [Documentation Doxygen/latex/_string_8h_source.tex](/Documentation%20Doxygen/latex/_string_8h_source.tex) | LaTeX | 270 | 0 | 3 | 273 |
| [Documentation Doxygen/latex/_time_8h_source.tex](/Documentation%20Doxygen/latex/_time_8h_source.tex) | LaTeX | 21 | 0 | 3 | 24 |
| [Documentation Doxygen/latex/_transformation_8h_source.tex](/Documentation%20Doxygen/latex/_transformation_8h_source.tex) | LaTeX | 380 | 0 | 3 | 383 |
| [Documentation Doxygen/latex/_vector_8h_source.tex](/Documentation%20Doxygen/latex/_vector_8h_source.tex) | LaTeX | 190 | 0 | 3 | 193 |
| [Documentation Doxygen/latex/_workspace_8h_source.tex](/Documentation%20Doxygen/latex/_workspace_8h_source.tex) | LaTeX | 84 | 0 | 3 | 87 |
| [Documentation Doxygen/latex/annotated.tex](/Documentation%20Doxygen/latex/annotated.tex) | LaTeX | 16 | 0 | 1 | 17 |
| [Documentation Doxygen/latex/class_b_w_pixel.tex](/Documentation%20Doxygen/latex/class_b_w_pixel.tex) | LaTeX | 53 | 0 | 28 | 81 |
| [Documentation Doxygen/latex/class_g_pixel.tex](/Documentation%20Doxygen/latex/class_g_pixel.tex) | LaTeX | 48 | 0 | 19 | 67 |
| [Documentation Doxygen/latex/class_interpreter.tex](/Documentation%20Doxygen/latex/class_interpreter.tex) | LaTeX | 17 | 0 | 3 | 20 |
| [Documentation Doxygen/latex/class_matrix.tex](/Documentation%20Doxygen/latex/class_matrix.tex) | LaTeX | 75 | 0 | 12 | 87 |
| [Documentation Doxygen/latex/class_p_b_m.tex](/Documentation%20Doxygen/latex/class_p_b_m.tex) | LaTeX | 43 | 0 | 19 | 62 |
| [Documentation Doxygen/latex/class_picture.tex](/Documentation%20Doxygen/latex/class_picture.tex) | LaTeX | 86 | 0 | 3 | 89 |
| [Documentation Doxygen/latex/class_pixel.tex](/Documentation%20Doxygen/latex/class_pixel.tex) | LaTeX | 41 | 0 | 28 | 69 |
| [Documentation Doxygen/latex/class_r_g_b_pixel.tex](/Documentation%20Doxygen/latex/class_r_g_b_pixel.tex) | LaTeX | 65 | 0 | 28 | 93 |
| [Documentation Doxygen/latex/class_session.tex](/Documentation%20Doxygen/latex/class_session.tex) | LaTeX | 84 | 0 | 31 | 115 |
| [Documentation Doxygen/latex/class_stack.tex](/Documentation%20Doxygen/latex/class_stack.tex) | LaTeX | 24 | 0 | 3 | 27 |
| [Documentation Doxygen/latex/class_string.tex](/Documentation%20Doxygen/latex/class_string.tex) | LaTeX | 106 | 0 | 12 | 118 |
| [Documentation Doxygen/latex/class_transform.tex](/Documentation%20Doxygen/latex/class_transform.tex) | LaTeX | 38 | 0 | 3 | 41 |
| [Documentation Doxygen/latex/class_vector.tex](/Documentation%20Doxygen/latex/class_vector.tex) | LaTeX | 87 | 0 | 12 | 99 |
| [Documentation Doxygen/latex/class_workspace.tex](/Documentation%20Doxygen/latex/class_workspace.tex) | LaTeX | 54 | 0 | 11 | 65 |
| [Documentation Doxygen/latex/doxygen.sty](/Documentation%20Doxygen/latex/doxygen.sty) | TeX | 471 | 63 | 63 | 597 |
| [Documentation Doxygen/latex/files.tex](/Documentation%20Doxygen/latex/files.tex) | LaTeX | 16 | 0 | 1 | 17 |
| [Documentation Doxygen/latex/hierarchy.tex](/Documentation%20Doxygen/latex/hierarchy.tex) | LaTeX | 22 | 0 | 1 | 23 |
| [Documentation Doxygen/latex/longtable_doxygen.sty](/Documentation%20Doxygen/latex/longtable_doxygen.sty) | TeX | 408 | 39 | 2 | 449 |
| [Documentation Doxygen/latex/make.bat](/Documentation%20Doxygen/latex/make.bat) | Batch | 47 | 1 | 9 | 57 |
| [Documentation Doxygen/latex/refman.tex](/Documentation%20Doxygen/latex/refman.tex) | LaTeX | 185 | 38 | 1 | 224 |
| [Documentation Doxygen/latex/struct_date_time.tex](/Documentation%20Doxygen/latex/struct_date_time.tex) | LaTeX | 23 | 0 | 17 | 40 |
| [Documentation Doxygen/latex/tabu_doxygen.sty](/Documentation%20Doxygen/latex/tabu_doxygen.sty) | TeX | 2,438 | 117 | 3 | 2,558 |
| [Helpers/Matrix.h](/Helpers/Matrix.h) | C++ | 189 | 49 | 9 | 247 |
| [Helpers/String.h](/Helpers/String.h) | C++ | 258 | 80 | 7 | 345 |
| [Helpers/Time.h](/Helpers/Time.h) | C++ | 14 | 12 | 1 | 27 |
| [Helpers/Vector.h](/Helpers/Vector.h) | C++ | 182 | 63 | 2 | 247 |
| [Interpreter.h](/Interpreter.h) | C++ | 228 | 19 | 12 | 259 |
| [Picture/BlackWhite.h](/Picture/BlackWhite.h) | C++ | 37 | 19 | 2 | 58 |
| [Picture/Gray.h](/Picture/Gray.h) | C++ | 37 | 19 | 0 | 56 |
| [Picture/Netpbm.h](/Picture/Netpbm.h) | C++ | 327 | 30 | 37 | 394 |
| [Picture/Pixel.h](/Picture/Pixel.h) | C++ | 9 | 13 | 1 | 23 |
| [Picture/RGB.h](/Picture/RGB.h) | C++ | 71 | 25 | 3 | 99 |
| [Session.cpp](/Session.cpp) | C++ | 2 | 0 | 0 | 2 |
| [Session.h](/Session.h) | C++ | 98 | 42 | 6 | 146 |
| [Transformation.h](/Transformation.h) | C++ | 355 | 6 | 16 | 377 |
| [Workspace.h](/Workspace.h) | C++ | 74 | 36 | 7 | 117 |
| [main.cpp](/main.cpp) | C++ | 14 | 0 | 2 | 16 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)