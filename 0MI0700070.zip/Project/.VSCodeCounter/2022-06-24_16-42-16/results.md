# Summary

Date : 2022-06-24 16:42:16

Directory d:\\OOP\\Project

Total : 225 files,  21560 codes, 1188 comments, 1330 blanks, all 24078 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| HTML | 108 | 9,957 | 290 | 379 | 10,626 |
| TeX | 3 | 3,317 | 219 | 68 | 3,604 |
| LaTeX | 36 | 3,227 | 38 | 284 | 3,549 |
| C++ | 15 | 1,895 | 413 | 105 | 2,413 |
| CSS | 3 | 1,709 | 56 | 342 | 2,107 |
| JavaScript | 55 | 1,257 | 170 | 133 | 1,560 |
| XML | 3 | 129 | 1 | 4 | 134 |
| Batch | 1 | 47 | 1 | 9 | 57 |
| Makefile | 1 | 22 | 0 | 6 | 28 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 225 | 21,560 | 1,188 | 1,330 | 24,078 |
| Documentation Doxygen | 210 | 19,665 | 775 | 1,225 | 21,665 |
| Documentation Doxygen\\html | 169 | 13,052 | 517 | 858 | 14,427 |
| Documentation Doxygen\\html\\search | 104 | 3,155 | 69 | 217 | 3,441 |
| Documentation Doxygen\\latex | 41 | 6,613 | 258 | 367 | 7,238 |
| Helpers | 4 | 643 | 204 | 19 | 866 |
| Picture | 5 | 481 | 106 | 43 | 630 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)