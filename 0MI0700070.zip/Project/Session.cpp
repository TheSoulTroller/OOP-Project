#include "Session.h"
int Session::nextId = 1;